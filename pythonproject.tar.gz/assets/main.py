import asyncio
import pygame
import sys
import os
import random
import math

# ─────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────
pygame.init()
pygame.mixer.init()

SCREEN_W, SCREEN_H = 1100, 550
screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
pygame.display.set_caption("Endless Runner")
clock = pygame.time.Clock()
FPS = 60

# ─────────────────────────────────────────────
# COLOURS
# ─────────────────────────────────────────────
SKY_TOP = (100, 160, 230)
SKY_BOT = (170, 210, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 40, 40)
YELLOW = (255, 220, 50)
GREEN = (50, 180, 80)
DARKGREY = (60, 60, 60)
GOLD = (255, 190, 30)

# ─────────────────────────────────────────────
# ASSET LOADING HELPER
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
MUSIC_DIR = os.path.join(BASE_DIR, "music")


def load(filename, w=None, h=None, colorkey=None):
    path = os.path.join(ASSET_DIR, filename)
    img = pygame.image.load(path).convert_alpha()
    if colorkey == "black":
        img.set_colorkey((0, 0, 0), pygame.RLEACCEL)
    if w and h:
        img = pygame.transform.smoothscale(img, (w, h))
    elif w:
        ratio = img.get_height() / img.get_width()
        img = pygame.transform.smoothscale(img, (w, int(w * ratio)))
    elif h:
        ratio = img.get_width() / img.get_height()
        img = pygame.transform.smoothscale(img, (int(h * ratio), h))
    return img

# ─────────────────────────────────────────────
# LOAD ASSETS  (all have black backgrounds → colorkey)
# ─────────────────────────────────────────────
CK = "black"

img_player = load("PC.png", h=110, colorkey=CK)
img_cart = load("Cart.png", w=220, colorkey=CK)
img_crowd = load("Crowd.png", h=110, colorkey=CK)
img_skateboard = load("Skateboard.png", h=60, colorkey=CK)
img_coffee = load("Coffee.png", h=55, colorkey=CK)
img_rocky = load("Rocky.png", h=150, colorkey=CK)  # the big bird mascot
img_teacher = load("Teacher.png", h=140, colorkey=CK)  # cloud fisherman
img_path_tile = load("PathTexture.jpg")

# ─────────────────────────────────────────────
# MUSIC
# ─────────────────────────────────────────────
jump_sound = pygame.mixer.Sound(os.path.join(MUSIC_DIR, "Jumping.ogg"))
grab_sound = pygame.mixer.Sound(os.path.join(MUSIC_DIR, "GrabEffect.ogg"))
damage_sound = pygame.mixer.Sound(os.path.join(MUSIC_DIR, "DamageNoise.ogg"))
bird_sound = pygame.mixer.Sound(os.path.join(MUSIC_DIR, "BirdNoise.ogg"))
pygame.mixer.music.load(os.path.join(MUSIC_DIR, "music.ogg"))
pygame.mixer.music.play(-1)

img_path_block = load("PathBlock.png", h=20, colorkey=CK)

img_title_screen = pygame.transform.smoothscale(
    pygame.image.load(os.path.join(ASSET_DIR, "TitleScreen.png")).convert_alpha(),
    (SCREEN_W, SCREEN_H)
)

PLAY_BTN_X = int(SCREEN_W * 0.49)
PLAY_BTN_Y = int(SCREEN_H * 0.68)
PLAY_BTN_R = int(SCREEN_H * 0.10)

# ─────────────────────────────────────────────
# GROUND
# ─────────────────────────────────────────────
GROUND_Y = SCREEN_H - 120
GROUND_H = SCREEN_H - GROUND_Y
FOOT_ADJUST = 45
PLAYER_FOOT = GROUND_Y + FOOT_ADJUST

path_tiles_x = math.ceil(SCREEN_W / img_path_tile.get_width()) + 2
path_tile_w = img_path_tile.get_width()
path_tile_h = img_path_tile.get_height()

path_tile_surf = img_path_tile.subsurface((0, 0, img_path_tile.get_width(), 40))

# ─────────────────────────────────────────────
# FONT
# ─────────────────────────────────────────────
try:
    font_big = pygame.font.SysFont("couriernew", 52, bold=True)
    font_med = pygame.font.SysFont("couriernew", 28, bold=True)
    font_sm = pygame.font.SysFont("couriernew", 20)
except:
    font_big = pygame.font.Font(None, 60)
    font_med = pygame.font.Font(None, 34)
    font_sm = pygame.font.Font(None, 24)

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────
BASE_SPEED = 5.0
GRAVITY = 0.7
JUMP_VEL = -18


SKATEBOARD_SPEED_BONUS = 8
SKATEBOARD_DURATION = 20  # seconds
COFFEE_SPEED_BONUS = 12
COFFEE_DURATION = 10  # seconds

ROCKY_DURATION = 10  # seconds Rocky slides on screen
ROCKY_INVINCIBLE = True  # while Rocky is on screen, one hit is forgiven

TEACHER_INTERVAL_MIN = 12  # seconds between teacher passes
TEACHER_INTERVAL_MAX = 22


# ─────────────────────────────────────────────
# BACKGROUND
# ─────────────────────────────────────────────
def draw_sky():
    for y in range(GROUND_Y):
        t = y / GROUND_Y
        r = int(SKY_TOP[0] + (SKY_BOT[0] - SKY_TOP[0]) * t)
        g = int(SKY_TOP[1] + (SKY_BOT[1] - SKY_TOP[1]) * t)
        b = int(SKY_TOP[2] + (SKY_BOT[2] - SKY_TOP[2]) * t)
        pygame.draw.line(screen, (r, g, b), (0, y), (SCREEN_W, y))


# ─────────────────────────────────────────────
# PLAYER
# ─────────────────────────────────────────────
class Player:
    W = img_player.get_width()
    H = img_player.get_height()

    def __init__(self):
        self.x = 160
        self.y = float(PLAYER_FOOT - self.H)
        self.vy = 0.0
        self.on_ground = True
        self.on_cart_roof = False
        self.dead = False

        # power-ups
        self.skate_timer = 0.0
        self.coffee_timer = 0.0
        self.speed_bonus = 0.0

        # Rocky shield
        self.rocky_timer = 0.0
        self.rocky_active = False
        self.rocky_x = self.x - img_rocky.get_width() - 100  # off-screen right initially
        self.rocky_going_right = False

        self.inv_flash = 0.0  # immunity seconds after first hit (prevents same-obstacle double-hit)
        self.damaged = False  # True while Rocky is actively chasing due to a real hit
        self.start_timer = 0.0
        self.rocky_spawned = False

    @property
    def rect(self):
        inset_x = self.W // 4
        inset_y = self.H // 5
        return pygame.Rect(int(self.x) + inset_x, int(self.y) + inset_y,
                           self.W - inset_x * 2, self.H - inset_y - self.H // 8)

    def update(self, dt, game_speed):
        self.start_timer += dt

        if self.start_timer >= 10 and not self.rocky_spawned:
            self.activate_rocky(from_damage=False)
            self.rocky_spawned = True
            self.rocky_timer = 3

        # Power-up timers
        if self.skate_timer > 0:
            self.skate_timer -= dt
            if self.skate_timer <= 0:
                self.skate_timer = 0
        if self.coffee_timer > 0:
            self.coffee_timer -= dt
            if self.coffee_timer <= 0:
                self.coffee_timer = 0

        # Speed bonus
        bonus = 0
        if self.skate_timer > 0:
            bonus = SKATEBOARD_SPEED_BONUS
        if self.coffee_timer > 0:
            bonus = max(bonus, COFFEE_SPEED_BONUS)
        self.speed_bonus = bonus

        # Rocky movement
        if self.rocky_active:
            self.rocky_timer -= dt
            target_x = self.x - img_rocky.get_width() + 30

            if self.rocky_timer <= 0:
                self.rocky_x += 12 * dt * 60
                if self.rocky_x > SCREEN_W + 50:
                    self.rocky_active = False
                    self.rocky_x = SCREEN_W + 200
                    self.damaged = False  # Rocky gone — player safe again
            elif not self.rocky_going_right:
                self.rocky_x -= 9 * dt * 60
                if self.rocky_x <= target_x:
                    self.rocky_x = target_x
                    self.rocky_going_right = True
            else:
                self.rocky_x += (target_x - self.rocky_x) * 0.1

        if not self.on_ground and not self.on_cart_roof:
            self.vy += GRAVITY
        self.y += self.vy

        if self.inv_flash > 0:
            self.inv_flash -= dt

    def jump(self):
        if self.on_ground or self.on_cart_roof:
            jump_sound.play()
            self.vy = JUMP_VEL
            self.on_ground = False
            self.on_cart_roof = False

    def land_on_ground(self):
        self.y = float(PLAYER_FOOT - self.H)
        self.vy = 0
        self.on_ground = True
        self.on_cart_roof = False

    def land_on_cart(self, roof_surface_y):
        """Snap player so their visible feet sit flush on roof_surface_y."""
        self.y = float(roof_surface_y - self.H + FOOT_ADJUST)
        self.vy = 0
        self.on_ground = False
        self.on_cart_roof = True

    def activate_rocky(self, from_damage=False):
        bird_sound.play()
        self.rocky_active = True
        self.rocky_timer = ROCKY_DURATION
        self.rocky_x = self.x - img_rocky.get_width() - 60
        self.rocky_going_right = False
        if from_damage:
            self.damaged = True
            self.inv_flash = 1.5

    def draw(self, surf):
        # Rocky behind player
        if self.rocky_active:
            rx = int(self.rocky_x)
            ry = int(PLAYER_FOOT - img_rocky.get_height())
            surf.blit(img_rocky, (rx, ry))

        # Flash player if briefly invincible
        if self.inv_flash > 0 and int(self.inv_flash * 10) % 2 == 0:
            return
        surf.blit(img_player, (int(self.x), int(self.y)))

        # Active power-up aura
        if self.coffee_timer > 0:
            s = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (255, 200, 50, 60), (0, 0, self.W, self.H))
            surf.blit(s, (int(self.x), int(self.y)))
        elif self.skate_timer > 0:
            s = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (50, 200, 255, 60), (0, 0, self.W, self.H))
            surf.blit(s, (int(self.x), int(self.y)))


# ─────────────────────────────────────────────
# OBSTACLES & POWER-UPS
# ─────────────────────────────────────────────
class Crowd:
    def __init__(self, x):
        self.x = float(x)
        self.img = img_crowd
        self.w = self.img.get_width()
        self.h = self.img.get_height()

    @property
    def rect(self):
        # draw_y is where the image top actually sits on screen
        draw_y = GROUND_Y - self.h + 10
        return pygame.Rect(
            int(self.x) + 30,  # trim a little off each side
            draw_y + 10,  # start 10px below image top
            max(self.w - 60, 20),  # never go negative — minimum 20px wide
            self.h - 25  # leave a small margin at the bottom
        )

    def update(self, dt, speed):
        self.x -= speed * dt * 60

    def draw(self, surf):
        surf.blit(self.img, (int(self.x), GROUND_Y - self.h + 10))

    def off_screen(self):
        return self.x + self.w < -10


class GolfCart:
    ROOF_SAFETY_PX = 55  # px from top of cart image to the visual roof surface — tune this if player hovers or sinks

    def __init__(self, x, has_skateboard=False):
        self.x = float(x)
        self.img = img_cart
        self.w = self.img.get_width()
        self.h = self.img.get_height()
        self.has_skateboard = has_skateboard

        # Compute where the "roof" sits in screen-space
        self.roof_y = PLAYER_FOOT - self.h + self.ROOF_SAFETY_PX

    @property
    def body_rect(self):
        # Lower half of cart only — keeps a clear gap above for roof landing
        top_frac = int(self.h * 0.50)
        return pygame.Rect(int(self.x) + 30,
                           PLAYER_FOOT - self.h + top_frac,
                           self.w - 60, self.h - top_frac)

    @property
    def roof_rect(self):
        # Generous landing zone on top
        return pygame.Rect(int(self.x) + 10, self.roof_y - 5,
                           self.w - 20, 22)

    def update(self, dt, speed):
        self.x -= speed * dt * 60
        self.roof_y = PLAYER_FOOT - self.h + self.ROOF_SAFETY_PX

    def draw(self, surf):
        surf.blit(self.img, (int(self.x), PLAYER_FOOT - self.h))
        if self.has_skateboard:
            sb_x = int(self.x) + self.w // 2 - img_skateboard.get_width() // 2
            sb_y = self.roof_y - img_skateboard.get_height() + 10
            surf.blit(img_skateboard, (sb_x, sb_y))

    def off_screen(self):
        return self.x + self.w < -10


class Skateboard:

    pass


class CoffeePickup:

    pass


class TeacherEvent:


    def __init__(self):
        self.reset()

    def reset(self):
        self.x = float(SCREEN_W + 50)
        self.active = False
        self.timer = 0.0
        self.next_time = random.uniform(TEACHER_INTERVAL_MIN, TEACHER_INTERVAL_MAX)
        # Coffee dangles from the hook
        self.hook_y = 0.0
        self.coffee_taken = False
        self.coffee_rect = pygame.Rect(0, 0, 0, 0)

    def try_spawn(self, dt):
        self.timer += dt
        if not self.active and self.timer >= self.next_time:
            self.active = True
            self.x = float(SCREEN_W + 50)
            self.coffee_taken = False

    def update(self, dt, speed):
        if not self.active:
            return
        self.x -= (speed * 0.6 + 2) * dt * 60

        # Hook swings
        self.hook_y = GROUND_Y - 80 + math.sin(pygame.time.get_ticks() / 400) * 30

        # Coffee rect
        if not self.coffee_taken:
            cx = int(self.x) + img_teacher.get_width() // 2 - img_coffee.get_width() // 2
            cy = int(self.hook_y)
            self.coffee_rect = pygame.Rect(cx, cy,
                                           img_coffee.get_width(),
                                           img_coffee.get_height())

        if self.x + img_teacher.get_width() < -20:
            self.active = False
            self.timer = 0
            self.next_time = random.uniform(TEACHER_INTERVAL_MIN, TEACHER_INTERVAL_MAX)

    def draw(self, surf):
        if not self.active:
            return
        ty = GROUND_Y - img_teacher.get_height() - 40
        surf.blit(img_teacher, (int(self.x), ty))

        if not self.coffee_taken:
            surf.blit(img_coffee, self.coffee_rect.topleft)


# ─────────────────────────────────────────────
# SCROLLING GROUND
# ─────────────────────────────────────────────
class Ground:
    def __init__(self):
        self.offset = 0.0

    def update(self, dt, speed):
        self.offset = (self.offset + speed * dt * 60) % path_tile_w

    def draw(self, surf):
        # fill ground (removes black area completely)
        pygame.draw.rect(
            surf,
            (130, 130, 130),
            (0, GROUND_Y, SCREEN_W, SCREEN_H - GROUND_Y)
        )

        # top edge line (makes it look like pavement)
        pygame.draw.line(
            surf,
            (190, 190, 190),
            (0, GROUND_Y),
            (SCREEN_W, GROUND_Y),
            4
        )


# ─────────────────────────────────────────────
# HUD
# ─────────────────────────────────────────────
def draw_hud(surf, score, speed, player):
    # Score
    txt = font_med.render(f"SCORE  {int(score):06d}", True, WHITE)
    surf.blit(txt, (20, 14))

    # Speed
    txt2 = font_sm.render(f"Speed ×{speed:.1f}", True, (220, 240, 255))
    surf.blit(txt2, (20, 50))

    # Power-up bars
    bar_x = SCREEN_W - 240
    if player.skate_timer > 0:
        draw_bar(surf, bar_x, 14, player.skate_timer, SKATEBOARD_DURATION,
                 (50, 200, 255), "SKATE")
    if player.coffee_timer > 0:
        draw_bar(surf, bar_x, 44, player.coffee_timer, COFFEE_DURATION,
                 YELLOW, "COFFEE")

    # Rocky indicator
    if player.rocky_active and player.rocky_timer > 0:
        colour = RED if player.rocky_timer < 5 else GOLD
        rt = font_med.render(f"⚠ ROCKY DANGER  {player.rocky_timer:.1f}s", True, colour)
        surf.blit(rt, (SCREEN_W // 2 - rt.get_width() // 2, 14))


def draw_bar(surf, x, y, val, maxval, colour, label):
    pygame.draw.rect(surf, DARKGREY, (x, y, 200, 18), border_radius=4)
    w = int(200 * min(val / maxval, 1.0))
    pygame.draw.rect(surf, colour, (x, y, w, 18), border_radius=4)
    lbl = font_sm.render(label, True, BLACK)
    surf.blit(lbl, (x + 4, y + 1))


# ─────────────────────────────────────────────
# SCREENS
# ─────────────────────────────────────────────
def draw_start_screen():
    screen.blit(img_title_screen, (0, 0))


def draw_game_over(score):
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    screen.blit(overlay, (0, 0))
    t1 = font_big.render("GAME OVER", True, RED)
    t2 = font_med.render(f"Score:  {int(score):06d}", True, WHITE)
    t3 = font_med.render("Press  R  to Restart  or  Q  to Quit", True, YELLOW)
    screen.blit(t1, (SCREEN_W // 2 - t1.get_width() // 2, 180))
    screen.blit(t2, (SCREEN_W // 2 - t2.get_width() // 2, 270))
    screen.blit(t3, (SCREEN_W // 2 - t3.get_width() // 2, 340))


# ─────────────────────────────────────────────
# MAIN GAME LOOP
# ─────────────────────────────────────────────
async def run_game():
    player = Player()
    ground = Ground()
    teacher = TeacherEvent()
    obstacles = []
    score = 0.0
    game_speed = BASE_SPEED
    dead = False
    spawn_timer = 0.0

    def spawn_obstacle():
        kind = random.choices([0, 1, 2], weights=[3, 2, 1])[0]
        x = float(SCREEN_W + 50)
        if kind == 0:
            obstacles.append(Crowd(x))
        else:
            has_skate = (kind == 2) and (player.skate_timer <= 0)
            obstacles.append(GolfCart(x, has_skateboard=has_skate))

    def next_spawn():
        return random.uniform(1.8, 3.5)

    spawn_next = next_spawn()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        dt = min(dt, 0.05)  # clamp for safety

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit();
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if dead:
                    if event.key == pygame.K_r:
                        return True  # restart
                    if event.key == pygame.K_q:
                        return False  # quit
                else:
                    if event.key in (pygame.K_SPACE, pygame.K_UP, pygame.K_w):
                        player.jump()

        if dead:
            draw_sky()
            ground.draw(screen)
            for obs in obstacles:
                obs.draw(screen)
            teacher.draw(screen)
            player.draw(screen)
            draw_game_over(score)
            pygame.display.flip()
            await asyncio.sleep(0)
            continue

        effective_speed = game_speed + player.speed_bonus
        game_speed = BASE_SPEED + score / 4000.0  # gradually faster
        game_speed = min(game_speed, 14.0)

        spawn_timer += dt
        if spawn_timer >= spawn_next:
            spawn_obstacle()
            spawn_timer = 0
            spawn_next = next_spawn()

        ground.update(dt, effective_speed)
        teacher.try_spawn(dt)
        teacher.update(dt, effective_speed)

        player.update(dt, effective_speed)

        player.on_ground = False
        was_on_cart_roof = player.on_cart_roof   # save BEFORE reset so persistence logic works
        player.on_cart_roof = False

        for obs in obstacles[:]:
            obs.update(dt, effective_speed)
            if obs.off_screen():
                obstacles.remove(obs)
                continue

            if isinstance(obs, GolfCart):
                p_rect = player.rect
                roof = obs.roof_rect
                body = obs.body_rect

                roof_surface_y = PLAYER_FOOT - obs.h + obs.ROOF_SAFETY_PX

                over_roof = (p_rect.right > roof.left + 5 and
                             p_rect.left < roof.right - 5)

                landing_on_roof = (player.vy >= 0 and
                                   p_rect.bottom >= roof.top - 5 and
                                   p_rect.bottom <= roof.top + 30)

                if over_roof and (landing_on_roof or was_on_cart_roof):
                    player.land_on_cart(roof_surface_y)
                    if obs.has_skateboard:
                        obs.has_skateboard = False
                        player.skate_timer = SKATEBOARD_DURATION
                        grab_sound.play()
                elif p_rect.colliderect(body):
                    if player.inv_flash > 0:
                        pass
                    elif player.damaged:
                        dead = True
                    else:
                        damage_sound.play()
                        player.activate_rocky(from_damage=True)


            elif isinstance(obs, Crowd):
                p = player.rect
                c = obs.rect
                if p.colliderect(c):
                    if player.vy >= 0 and p.bottom <= c.top + 20:
                        pass
                    elif player.inv_flash > 0:
                        pass
                    elif player.damaged:
                        dead = True
                    else:
                        damage_sound.play()
                        player.activate_rocky(from_damage=True)

        if player.y + player.H >= PLAYER_FOOT:
            if not player.on_cart_roof:
                player.land_on_ground()

        if teacher.active and not teacher.coffee_taken:
            if player.rect.colliderect(teacher.coffee_rect):
                teacher.coffee_taken = True
                player.coffee_timer = COFFEE_DURATION
                grab_sound.play()

        score += effective_speed * dt * 60 * 0.1

        draw_sky()
        ground.draw(screen)

        for obs in obstacles:
            obs.draw(screen)

        teacher.draw(screen)
        player.draw(screen)
        draw_hud(screen, score, effective_speed, player)

        pygame.display.flip()
        await asyncio.sleep(0)

    return False

async def main():
    while True:
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit();
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        waiting = False
                    if event.key == pygame.K_q:
                        pygame.quit();
                        sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    mx, my = event.pos
                    dist = math.hypot(mx - PLAY_BTN_X, my - PLAY_BTN_Y)
                    if dist <= PLAY_BTN_R:
                        waiting = False
            draw_start_screen()
            pygame.display.flip()
            clock.tick(FPS)
            await asyncio.sleep(0)

        again = await run_game()
        if not again:
            break

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())